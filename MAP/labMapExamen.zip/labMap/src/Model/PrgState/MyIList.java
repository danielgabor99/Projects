package Model.PrgState;

import java.util.ArrayList;
import java.util.LinkedList;

public interface MyIList<T> {


    T getFirst();

    void addB(T prg);

    LinkedList<T> getValues();
}
