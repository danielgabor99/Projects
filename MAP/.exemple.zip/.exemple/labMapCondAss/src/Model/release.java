package Model;

import Model.PrgState.MyIDictionary;
import Model.PrgState.MyIStack;
import Model.PrgState.PrgState;
import Model.PrgState.SemaphoreI;
import Model.Type.IntType;
import Model.Type.Type;
import Model.Value.Value;
import com.company.MyException;
import org.javatuples.Triplet;

import java.io.FileNotFoundException;
import java.util.List;

public class release  implements IStmt{
    String var;
    public release(String v){
        var=v;
    }
    @Override
    public PrgState execute(PrgState state) throws MyException, FileNotFoundException {
        MyIStack<IStmt> stk=state.getStk();
        MyIDictionary<String, Value> symTbl= state.getSymTable();
        SemaphoreI<Integer, Triplet<Integer, List<Integer>,Integer>> sem=state.getSem();
        if(symTbl.isDefined(var)){
            Value foundindex=symTbl.lookup(var);
            if(foundindex.getType() instanceof IntType)
                if(!sem.isDefined((Integer) foundindex.getVal()))
                    throw new MyException("is not defined");
                else {
                    Triplet<Integer, List<Integer>, Integer> foundSem = sem.lookup((Integer) foundindex.getVal());
                    if(foundSem.getValue1().contains(state.t_id))
                        foundSem.getValue1().remove(foundSem.getValue1().indexOf(state.t_id));
                }
        }
        return null;
    }

    @Override
    public MyIDictionary<String, Type> typecheck(MyIDictionary<String, Type> typeEnv) throws MyException {
        return null;
    }
}
