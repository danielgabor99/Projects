package Model;

import Model.Exp.Exp;
import Model.PrgState.MyIDictionary;
import Model.PrgState.MyIStack;
import Model.PrgState.PrgState;
import Model.PrgState.SemaphoreI;
import Model.Type.Type;
import Model.Value.IntValue;
import Model.Value.Value;
import com.company.MyException;
import org.javatuples.Triplet;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class newSemaphore implements IStmt {
    String var;
    Exp exp1,exp2;
    public newSemaphore(String v, Exp e1, Exp e2){
        var=v;
        exp1=e1;
        exp2=e2;
    }
    @Override
    public PrgState execute(PrgState state) throws MyException, FileNotFoundException {
        MyIStack<IStmt> stk=state.getStk();
        MyIDictionary<String, Value> symTbl= state.getSymTable();
        SemaphoreI<Integer, Triplet<Integer, List<Integer>,Integer>> sem=state.getSem();
        Value v1=exp1.eval(symTbl,state.getHeap());
        Value v2=exp2.eval(symTbl,state.getHeap());
        List<Integer> l=new ArrayList<>();
        Triplet<Integer,List<Integer>,Integer> trip=new Triplet<>((Integer)v1.getVal(), l,(Integer) v2.getVal());
        int i=sem.getFirstFree();
        sem.update(i,trip);
        if(symTbl.isDefined(var))
            symTbl.update(var,new IntValue(i));

        return null;
    }

    @Override
    public MyIDictionary<String, Type> typecheck(MyIDictionary<String, Type> typeEnv) throws MyException {
        return null;
    }
}
