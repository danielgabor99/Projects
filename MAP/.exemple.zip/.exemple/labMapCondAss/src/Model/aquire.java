package Model;

import Model.PrgState.MyIDictionary;
import Model.PrgState.MyIStack;
import Model.PrgState.PrgState;
import Model.PrgState.SemaphoreI;
import Model.Type.IntType;
import Model.Type.Type;
import Model.Value.IntValue;
import Model.Value.Value;
import com.company.MyException;
import org.javatuples.Triplet;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class aquire implements IStmt {
    String var;
    public aquire(String v){var=v;}
    @Override
    public PrgState execute(PrgState state) throws MyException, FileNotFoundException {
        MyIStack<IStmt> stk=state.getStk();
        MyIDictionary<String, Value> symTbl= state.getSymTable();
        SemaphoreI<Integer, Triplet<Integer, List<Integer>,Integer>> sem=state.getSem();

        if(symTbl.isDefined(var)) {
            Value foundIndex = symTbl.lookup(var);
            if(foundIndex.getType() instanceof IntType){
               if( sem.isDefined((Integer) foundIndex.getVal())){
                    List<Integer> l=new ArrayList<>();
                    Triplet<Integer,List<Integer>,Integer> found=sem.lookup((Integer) foundIndex.getVal());
                    int LN=found.getValue1().size();
                    if(found.getValue0()-found.getValue2()>LN) {
                        if (found.getValue1().contains(state.t_id))
                            return null;
                        else
                            found.getValue1().add(state.t_id);
                    }else
                        stk.push(new aquire(var));
               }
            }

        }
        return null;
    }

    @Override
    public MyIDictionary<String, Type> typecheck(MyIDictionary<String, Type> typeEnv) throws MyException {
        return null;
    }
}
