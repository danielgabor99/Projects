package Model.PrgState;

public interface MyIStack<T> {

    T pop();
    void push(T v);
    public boolean isEmpty();
}
