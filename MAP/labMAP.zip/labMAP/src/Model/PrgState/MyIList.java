package Model.PrgState;

public interface MyIList<T> {


    T getFirst();

    void addB(T prg);
}
