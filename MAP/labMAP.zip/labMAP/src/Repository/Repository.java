package Repository;

import Model.PrgState.MyIDictionary;
import Model.PrgState.MyList;
import Model.PrgState.PrgState;
import com.company.MyException;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Repository implements RepositoryI{
    String logFilePath;
    PrgState prg;
    List<PrgState> List;
    public Repository(PrgState prg, String File) throws FileNotFoundException {
        this.List = new ArrayList<>();
        this.logFilePath=File;
        this.prg=prg;
        this.add(prg);
    }
    @Override
    public List<PrgState> getPrgList(){
        return (java.util.List<PrgState>) List;
    }

    @Override
    public void setPrgList(List<PrgState> l) {
        List= (java.util.List<PrgState>) l;
    }

    public void add(PrgState prg) {
        List.add(prg);
    }
    public void logPrgStateExec(PrgState p) throws MyException, IOException {
        int id= p.id;
        String s="id="+id+"\n";
        PrintWriter logFile = new PrintWriter(new BufferedWriter(new FileWriter(logFilePath, true)));
        PrgState prg = p;//?
        logFile.append(prg.getStk().toString());
        logFile.append(s);
        logFile.append(prg.getSymTable().toString());
        logFile.append(prg.getOut().toString());
        logFile.append(prg.getFileTable().toString());
        logFile.append(prg.getHeap().toString());
        logFile.flush();
    }
}
